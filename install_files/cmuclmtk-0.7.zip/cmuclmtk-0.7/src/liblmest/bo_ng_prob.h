#ifndef BO_NG_PROB_H
#define BO_NG_PROB_H

void warn_prob_error(id__t *sought_ngram, unsigned short context_length, double prob);

#endif
